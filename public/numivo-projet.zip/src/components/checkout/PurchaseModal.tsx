import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { COUNTRIES, SERVICES } from '../../data/mockData';
import { calculateSellingPrice } from '../../utils/pricing';
import { MobileMoneyOperator, NumberType, PaymentMethod } from '../../types';
import { X, Smartphone, CreditCard, Wallet, ShieldCheck, CheckCircle2, ArrowRight, Loader2, AlertCircle } from 'lucide-react';

interface PurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCountryCode?: string;
  initialServiceId?: string;
  initialType?: NumberType;
  onSuccess: (orderId: string) => void;
}

export const PurchaseModal: React.FC<PurchaseModalProps> = ({
  isOpen,
  onClose,
  initialCountryCode = 'BJ',
  initialServiceId = 'whatsapp',
  initialType = 'TEMPORARY',
  onSuccess,
}) => {
  const { catalog, currency, pricingConfig, exchangeRates, wallet, createOrder, setRole } = useApp();

  const [countryCode, setCountryCode] = useState(initialCountryCode);
  const [serviceId, setServiceId] = useState(initialServiceId);
  const [type, setType] = useState<NumberType>(initialType);

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('MOBILE_MONEY');
  const [mobileOperator, setMobileOperator] = useState<MobileMoneyOperator>('MTN');
  const [mobilePhone, setMobilePhone] = useState('+229 97 00 11 22');

  // Card details state (mocked secure form)
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8912');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvv, setCardCvv] = useState('•••');
  const [cardHolder, setCardHolder] = useState('Jean Dupont');

  // Checkout submission states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState<'CONFIG' | 'GATEWAY_PROMPT' | 'SUCCESS'>('CONFIG');
  const [gatewayStatusMessage, setGatewayStatusMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  // Selected item and calculation
  const catalogItem = catalog.find(
    (c) => c.countryCode === countryCode && c.serviceId === serviceId && c.type === type
  ) || catalog[0];

  const currentCountry = COUNTRIES.find((c) => c.code === countryCode) || COUNTRIES[0];
  const currentService = SERVICES.find((s) => s.id === serviceId) || SERVICES[0];

  const priceCalculation = calculateSellingPrice({
    supplierCostXof: catalogItem?.supplierCostXof || 1200,
    paymentMethod,
    targetCurrency: currency,
    config: pricingConfig,
    rates: exchangeRates,
  });

  const walletBalance = wallet.balances[currency];
  const hasEnoughWalletBalance = walletBalance >= priceCalculation.sellingPriceInCurrency;

  const handleStartPayment = async () => {
    setErrorMessage('');

    if (paymentMethod === 'WALLET' && !hasEnoughWalletBalance) {
      setErrorMessage(`Solde insuffisant dans votre portefeuille ${currency}. Solde : ${walletBalance} ${currency}. Veuillez recharger.`);
      return;
    }

    setIsSubmitting(true);

    if (paymentMethod === 'MOBILE_MONEY') {
      setStep('GATEWAY_PROMPT');
      setGatewayStatusMessage(`Demande de débit USSD transmise à votre téléphone ${mobileOperator} (${mobilePhone}). Veuillez valider sur votre mobile...`);
    } else if (paymentMethod === 'CARD') {
      setStep('GATEWAY_PROMPT');
      setGatewayStatusMessage('Interrogation de la banque émettrice... Vérification 3D Secure en cours.');
    } else {
      // WALLET is instant
      await finalizePayment();
    }
  };

  const finalizePayment = async () => {
    setIsSubmitting(true);
    try {
      const result = await createOrder({
        countryCode,
        serviceId,
        type,
        paymentMethod,
        mobileMoneyOperator: paymentMethod === 'MOBILE_MONEY' ? mobileOperator : undefined,
        mobileMoneyPhone: paymentMethod === 'MOBILE_MONEY' ? mobilePhone : undefined,
      });

      if (result.success) {
        // Automatically set role to CLIENT to seamlessly show customer workspace
        setRole('CLIENT');
        setStep('SUCCESS');
        setTimeout(() => {
          setIsSubmitting(false);
          onSuccess(result.order.id);
          onClose();
        }, 1500);
      } else {
        setErrorMessage(result.error || 'Erreur lors du traitement.');
        setStep('CONFIG');
        setIsSubmitting(false);
      }
    } catch {
      setErrorMessage('Une erreur imprévue est survenue.');
      setStep('CONFIG');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="w-full max-w-xl rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Commande de Numéro Virtuel
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Fournisseur Ultra SMS · Durée de réception : 20 min
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting && step === 'GATEWAY_PROMPT'}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-600 dark:text-slate-300">
          
          {step === 'CONFIG' && (
            <>
              {/* Product Summary Box */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">
                    Pays
                  </label>
                  <select
                    value={countryCode}
                    onChange={(e) => setCountryCode(e.target.value)}
                    className="w-full text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 p-2"
                  >
                    {COUNTRIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.flag} {c.name} ({c.prefix})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">
                    Service
                  </label>
                  <select
                    value={serviceId}
                    onChange={(e) => setServiceId(e.target.value)}
                    className="w-full text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 p-2"
                  >
                    {SERVICES.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2">
                  Choisissez votre mode de paiement
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  
                  {/* Mobile Money */}
                  <button
                    onClick={() => setPaymentMethod('MOBILE_MONEY')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      paymentMethod === 'MOBILE_MONEY'
                        ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/20 text-slate-900 dark:text-white ring-1 ring-emerald-600'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-amber-500 mb-1.5" />
                    <div className="font-bold text-xs">Mobile Money</div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">MTN, Moov, Celtiis</div>
                  </button>

                  {/* Card */}
                  <button
                    onClick={() => setPaymentMethod('CARD')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      paymentMethod === 'CARD'
                        ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/20 text-slate-900 dark:text-white ring-1 ring-emerald-600'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <CreditCard className="w-5 h-5 text-blue-500 mb-1.5" />
                    <div className="font-bold text-xs">Carte Bancaire</div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">Visa, Mastercard (3DS)</div>
                  </button>

                  {/* Internal Wallet */}
                  <button
                    onClick={() => setPaymentMethod('WALLET')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      paymentMethod === 'WALLET'
                        ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/20 text-slate-900 dark:text-white ring-1 ring-emerald-600'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <Wallet className="w-5 h-5 text-emerald-500 mb-1.5" />
                    <div className="font-bold text-xs">Portefeuille</div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                      {walletBalance.toLocaleString('fr-FR')} {currency}
                    </div>
                  </button>

                </div>
              </div>

              {/* Sub-form based on chosen payment method */}
              {paymentMethod === 'MOBILE_MONEY' && (
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      Opérateur Mobile Money (Passerelle FedaPay / KKiaPay)
                    </span>
                    <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400">Push USSD instantané</span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2">
                    {(['MTN', 'MOOV', 'CELTIIS'] as MobileMoneyOperator[]).map((op) => (
                      <button
                        key={op}
                        type="button"
                        onClick={() => setMobileOperator(op)}
                        className={`py-2 px-3 rounded-lg border text-xs font-semibold text-center transition-colors ${
                          mobileOperator === op
                            ? 'border-amber-500 bg-amber-500/10 text-amber-700 dark:text-amber-300 font-bold'
                            : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {op === 'MTN' ? '🟡 MTN MoMo' : op === 'MOOV' ? '🔵 Moov Flooz' : '🟢 Celtiis SBIN'}
                      </button>
                    ))}
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      Numéro Mobile Money pour recevoir la notification :
                    </label>
                    <input
                      type="tel"
                      value={mobilePhone}
                      onChange={(e) => setMobilePhone(e.target.value)}
                      placeholder="+229 97 00 00 00"
                      className="w-full text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              )}

              {paymentMethod === 'CARD' && (
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      Carte Bancaire Sécurisée
                    </span>
                    <span className="text-[10px] font-mono text-blue-500">3D Secure v2</span>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      Numéro de carte
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 mb-1">
                        Date d'expiration
                      </label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        className="w-full text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-500 mb-1">
                        Code CVC / CVV
                      </label>
                      <input
                        type="text"
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        className="w-full text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'WALLET' && (
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      Paiement par Solde Interne ({currency})
                    </span>
                    <span className="text-[10px] font-mono text-emerald-600 font-bold">Sans frais de commission</span>
                  </div>
                  <div className="flex items-baseline justify-between text-xs pt-1">
                    <span className="text-slate-500">Votre solde disponible :</span>
                    <span className="font-bold font-mono text-slate-900 dark:text-white">
                      {walletBalance.toLocaleString('fr-FR')} {currency}
                    </span>
                  </div>
                  {!hasEnoughWalletBalance && (
                    <p className="text-[11px] text-rose-500 pt-1">
                      Votre solde est insuffisant pour finaliser cet achat. Veuillez utiliser Mobile Money ou carte bancaire.
                    </p>
                  )}
                </div>
              )}

              {/* Price Breakdown Summary */}
              <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-slate-400 font-mono uppercase">
                    Total à payer ({currency})
                  </div>
                  <div className="text-xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                    {priceCalculation.sellingPriceFormatted}
                  </div>
                </div>
                <div className="text-right text-[11px] text-slate-400 font-mono">
                  <div>Marge nette : 2 000 XOF</div>
                  <div className="text-emerald-600 dark:text-emerald-400">Garantie remboursement 100%</div>
                </div>
              </div>

              {errorMessage && (
                <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Submit CTA */}
              <button
                onClick={handleStartPayment}
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Création de la commande...</span>
                  </>
                ) : (
                  <>
                    <span>Confirmer et Payer {priceCalculation.sellingPriceFormatted}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </>
          )}

          {/* STEP 2: GATEWAY PUSH SIMULATOR */}
          {step === 'GATEWAY_PROMPT' && (
            <div className="py-8 text-center space-y-5">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-500 mx-auto flex items-center justify-center animate-pulse">
                <Smartphone className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white">
                  {paymentMethod === 'MOBILE_MONEY'
                    ? `Notification USSD envoyée (${mobileOperator})`
                    : 'Validation 3D Secure Bancaire'}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 max-w-sm mx-auto">
                  {gatewayStatusMessage}
                </p>
              </div>

              {/* Simulation prompt box */}
              <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-3 max-w-sm mx-auto text-left">
                <div className="flex justify-between font-mono text-[11px] text-slate-400">
                  <span>Passerelle : FedaPay / KKiaPay</span>
                  <span>ID : tx_live_891</span>
                </div>
                <div className="font-semibold text-slate-900 dark:text-white">
                  Débit de {priceCalculation.sellingPriceFormatted} vers Numivo
                </div>
                <p className="text-[11px] text-slate-500">
                  (Dans un environnement réel, tapez votre code secret MoMo sur votre smartphone. Cliquez ci-dessous pour simuler l'approbation du webhook serveur).
                </p>
              </div>

              <div className="flex gap-3 justify-center pt-2">
                <button
                  onClick={() => setStep('CONFIG')}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                >
                  Annuler
                </button>
                <button
                  onClick={finalizePayment}
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center gap-2 shadow-sm"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Simuler validation sur le téléphone</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: SUCCESS */}
          {step === 'SUCCESS' && (
            <div className="py-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 text-emerald-500 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-lg font-bold text-slate-900 dark:text-white">
                Paiement Confirmé !
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Votre numéro virtuel a été alloué par Ultra SMS. Redirection vers votre boîte de réception SMS en direct...
              </p>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
