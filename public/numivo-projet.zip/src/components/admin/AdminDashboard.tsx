import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { COUNTRIES, SERVICES } from '../../data/mockData';
import {
  Shield,
  TrendingUp,
  DollarSign,
  Smartphone,
  Settings,
  Server,
  FileText,
  RefreshCw,
  Sliders,
  CheckCircle2,
  AlertOctagon,
  Percent,
  ToggleLeft,
  ToggleRight,
  Eye,
  RotateCcw,
} from 'lucide-react';
import { formatCurrency } from '../../utils/pricing';

export const AdminDashboard: React.FC = () => {
  const {
    orders,
    catalog,
    wallet,
    pricingConfig,
    providerConfig,
    auditLogs,
    updatePricingConfig,
    updateCatalogItem,
    updateProviderConfig,
    syncProvider,
    cancelAndRefundOrder,
  } = useApp();

  const [adminTab, setAdminTab] = useState<'financials' | 'orders' | 'catalog' | 'pricing' | 'provider' | 'audit'>(
    'financials'
  );

  // Form states for pricing rules
  const [targetMarginInput, setTargetMarginInput] = useState(pricingConfig.targetMarginXof);
  const [momoRateInput, setMomoRateInput] = useState(pricingConfig.paymentRateMobileMoney * 100);
  const [cardRateInput, setCardRateInput] = useState(pricingConfig.paymentRateCard * 100);
  const [roundingStepInput, setRoundingStepInput] = useState(pricingConfig.roundingStepXof);
  const [pricingSavedToast, setPricingSavedToast] = useState(false);

  // Form states for Ultra SMS Provider
  const [apiKeyInput, setApiKeyInput] = useState(providerConfig.apiKey);
  const [isSandboxInput, setIsSandboxInput] = useState(providerConfig.isSandbox);
  const [isSyncing, setIsSyncing] = useState(false);

  // FINANCIAL TELEMETRY CALCULATIONS (Section 16 du Cahier des Charges)
  const completedOrders = orders.filter((o) => o.status === 'COMPLETED');
  const paidOrCompletedOrders = orders.filter((o) => o.status === 'COMPLETED' || o.status === 'PROCESSING');
  const refundedOrders = orders.filter((o) => o.status === 'REFUNDED');

  const grossRevenueXof = paidOrCompletedOrders.reduce((acc, curr) => acc + curr.sellingPriceXof, 0);
  const totalSupplierCostXof = paidOrCompletedOrders.reduce((acc, curr) => acc + curr.supplierCostXof, 0);
  const totalPaymentFeesXof = paidOrCompletedOrders.reduce((acc, curr) => acc + curr.paymentFeeXof, 0);
  const totalRefundedXof = refundedOrders.reduce((acc, curr) => acc + curr.sellingPriceXof, 0);
  
  // Realized Net Profit
  const netProfitXof = grossRevenueXof - totalSupplierCostXof - totalPaymentFeesXof;

  // Average margin per sold number
  const averageMarginPerNumber =
    paidOrCompletedOrders.length > 0 ? Math.round(netProfitXof / paidOrCompletedOrders.length) : pricingConfig.targetMarginXof;

  // Client funds in wallet (Crucial rule: Section 6.3 & 16: client wallet funds are liabilities, NOT platform revenue!)
  const totalClientWalletFundsXof = wallet.balances.XOF;

  const handleSavePricing = (e: React.FormEvent) => {
    e.preventDefault();
    updatePricingConfig({
      targetMarginXof: Number(targetMarginInput),
      paymentRateMobileMoney: Number(momoRateInput) / 100,
      paymentRateCard: Number(cardRateInput) / 100,
      roundingStepXof: Number(roundingStepInput),
    });
    setPricingSavedToast(true);
    setTimeout(() => setPricingSavedToast(false), 2500);
  };

  const handleSaveProvider = (e: React.FormEvent) => {
    e.preventDefault();
    updateProviderConfig({
      apiKey: apiKeyInput,
      isSandbox: isSandboxInput,
    });
  };

  const handleSyncPing = async () => {
    setIsSyncing(true);
    await syncProvider();
    setTimeout(() => setIsSyncing(false), 800);
  };

  return (
    <div className="py-8 bg-slate-50 dark:bg-slate-950 min-h-[calc(100vh-4rem)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Admin Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              <Shield className="w-3.5 h-3.5" />
              <span>Console d'Administration & Pilotage</span>
              <span aria-hidden="true">·</span>
              <span>Ultra SMS Gateway</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              Supervision Numivo & Rentabilité
            </h1>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              Ultra SMS : {providerConfig.isSandbox ? 'SANDBOX ACTIVE' : 'LIVE PRODUCTION'}
            </span>
            <button
              onClick={handleSyncPing}
              disabled={isSyncing}
              className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100"
              title="Tester la connexion API"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
          {[
            { id: 'financials', label: 'Rapports & Rentabilité (2 000 XOF)', icon: TrendingUp },
            { id: 'orders', label: 'Gestion des Commandes', icon: FileText, count: orders.length },
            { id: 'catalog', label: 'Catalogue & Coûts Fournisseur', icon: Smartphone, count: catalog.length },
            { id: 'pricing', label: 'Règles de Prix & Marges', icon: Sliders },
            { id: 'provider', label: 'Fournisseur Ultra SMS', icon: Server },
            { id: 'audit', label: 'Journal d\'Audit', icon: Shield, count: auditLogs.length },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setAdminTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
                  adminTab === tab.id
                    ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span className="font-mono text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800">
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB 1: FINANCIALS & RENTABILITY */}
        {adminTab === 'financials' && (
          <div className="space-y-6">
            
            {/* KPI Cards Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">
                  Chiffre d'Affaires Brut
                </span>
                <div className="text-2xl font-black font-mono text-slate-900 dark:text-white mt-2">
                  {grossRevenueXof.toLocaleString('fr-FR')} XOF
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  {paidOrCompletedOrders.length} numéros facturés
                </div>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">
                  Coût Fournisseur Déduit
                </span>
                <div className="text-2xl font-black font-mono text-rose-500 mt-2">
                  - {totalSupplierCostXof.toLocaleString('fr-FR')} XOF
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  Achat chez grossiste Ultra SMS
                </div>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">
                  Commissions Passerelles
                </span>
                <div className="text-2xl font-black font-mono text-amber-500 mt-2">
                  - {totalPaymentFeesXof.toLocaleString('fr-FR')} XOF
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  FedaPay, KKiaPay & Cartes
                </div>
              </div>

              <div className="p-4 rounded-xl border border-emerald-500/40 bg-emerald-50/20 dark:bg-emerald-950/20">
                <span className="text-xs text-emerald-700 dark:text-emerald-400 uppercase tracking-wider font-bold">
                  Bénéfice Net Réalisé
                </span>
                <div className="text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400 mt-2">
                  {netProfitXof.toLocaleString('fr-FR')} XOF
                </div>
                <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold mt-1 font-mono">
                  Marge moy. : {averageMarginPerNumber.toLocaleString('fr-FR')} XOF / n° (≥ 2 000 XOF ✓)
                </div>
              </div>

            </div>

            {/* Regulatory Balance Warning: Client Wallet Funds vs Company Revenue */}
            <div className="p-5 rounded-2xl border border-amber-200 dark:border-amber-900/50 bg-amber-50/50 dark:bg-amber-950/20 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300">
                  <AlertOctagon className="w-4 h-4 text-amber-600" />
                  <span>Obligation Comptable (Article 6.3 & 16) : Ségrégation des Fonds Clients</span>
                </div>
                <p className="text-xs text-amber-700 dark:text-amber-400 max-w-2xl">
                  Les soldes des portefeuilles clients (<strong className="font-mono">{totalClientWalletFundsXof.toLocaleString('fr-FR')} XOF</strong>) constituent une dette envers les clients et ne doivent jamais être confondus avec le chiffre d'affaires ou le bénéfice de l'entreprise.
                </p>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-amber-200 dark:border-amber-800 text-right shrink-0">
                <div className="text-[10px] text-slate-400 uppercase font-mono">Fonds Clients Cloisonnés</div>
                <div className="text-lg font-black font-mono text-slate-900 dark:text-white">
                  {totalClientWalletFundsXof.toLocaleString('fr-FR')} XOF
                </div>
              </div>
            </div>

            {/* Breakdown by Service Table */}
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
              <div className="p-4 border-b border-slate-200 dark:border-slate-800">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Rentabilité par Service & Respect de la Règle de Marge
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 dark:bg-slate-950/60 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-2.5 px-4">Service</th>
                      <th className="py-2.5 px-4 text-right">Commandes</th>
                      <th className="py-2.5 px-4 text-right">CA Brut</th>
                      <th className="py-2.5 px-4 text-right">Coût Ultra SMS</th>
                      <th className="py-2.5 px-4 text-right">Frais Passerelle</th>
                      <th className="py-2.5 px-4 text-right">Marge Nette</th>
                      <th className="py-2.5 px-4 text-center">Conformité Marge</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                    {SERVICES.slice(0, 6).map((service) => {
                      const serviceOrders = paidOrCompletedOrders.filter((o) => o.serviceId === service.id);
                      const count = serviceOrders.length;
                      const ca = serviceOrders.reduce((a, b) => a + b.sellingPriceXof, 0);
                      const cost = serviceOrders.reduce((a, b) => a + b.supplierCostXof, 0);
                      const fees = serviceOrders.reduce((a, b) => a + b.paymentFeeXof, 0);
                      const margin = ca - cost - fees;
                      const isCompliant = count === 0 || margin / count >= pricingConfig.targetMarginXof;

                      return (
                        <tr key={service.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                          <td className="py-3 px-4 font-sans font-bold text-slate-900 dark:text-white">
                            {service.name}
                          </td>
                          <td className="py-3 px-4 text-right">{count}</td>
                          <td className="py-3 px-4 text-right font-semibold">{ca.toLocaleString('fr-FR')} XOF</td>
                          <td className="py-3 px-4 text-right text-rose-500">{cost.toLocaleString('fr-FR')} XOF</td>
                          <td className="py-3 px-4 text-right text-amber-500">{fees.toLocaleString('fr-FR')} XOF</td>
                          <td className="py-3 px-4 text-right font-bold text-emerald-600 dark:text-emerald-400">
                            {margin.toLocaleString('fr-FR')} XOF
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                              ≥ 2 000 XOF ✓
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: ORDERS MANAGEMENT */}
        {adminTab === 'orders' && (
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Supervision des Commandes Clients
                </h3>
                <p className="text-xs text-slate-500">
                  Vérification des statuts fournisseur, SMS et gestion des remboursements
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 dark:bg-slate-950/60 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-2.5 px-4">Réf & Date</th>
                    <th className="py-2.5 px-4">Client</th>
                    <th className="py-2.5 px-4">Service & Numéro</th>
                    <th className="py-2.5 px-4 text-right">Prix Client</th>
                    <th className="py-2.5 px-4 text-right">Coût Ultra SMS</th>
                    <th className="py-2.5 px-4 text-right">Marge Nette</th>
                    <th className="py-2.5 px-4 text-center">Statut</th>
                    <th className="py-2.5 px-4 text-right">Action Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                  {orders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 dark:text-white">{ord.reference}</div>
                        <div className="text-[10px] text-slate-400">
                          {new Date(ord.createdAt).toLocaleDateString('fr-FR')} {new Date(ord.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-sans text-slate-600 dark:text-slate-400">
                        {ord.userEmail}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-sans font-semibold text-slate-900 dark:text-white">
                          {ord.serviceName} ({ord.countryName})
                        </div>
                        <div className="text-emerald-600 font-bold">{ord.phoneNumber}</div>
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-slate-900 dark:text-white">
                        {ord.sellingPriceXof.toLocaleString('fr-FR')} XOF
                      </td>
                      <td className="py-3 px-4 text-right text-rose-500">
                        {ord.supplierCostXof.toLocaleString('fr-FR')} XOF
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-600 dark:text-emerald-400">
                        +{ord.actualMarginXof.toLocaleString('fr-FR')} XOF
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            ord.status === 'COMPLETED'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300'
                              : ord.status === 'PROCESSING'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300'
                              : ord.status === 'REFUNDED'
                              ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-300'
                              : 'bg-slate-100 text-slate-800'
                          }`}
                        >
                          {ord.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-sans">
                        {ord.status !== 'REFUNDED' && (
                          <button
                            onClick={() => cancelAndRefundOrder(ord.id, 'Remboursement forcé par administrateur')}
                            className="px-2.5 py-1 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded border border-rose-200 dark:border-rose-900"
                          >
                            Rembourser
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: CATALOG & BASE COSTS */}
        {adminTab === 'catalog' && (
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Gestionnaire de Catalogue & Coûts Grossiste Ultra SMS
                </h3>
                <p className="text-xs text-slate-500">
                  Ajustez les coûts de base et activez/désactivez les services par pays
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 dark:bg-slate-950/60 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-2.5 px-4">Pays</th>
                    <th className="py-2.5 px-4">Service</th>
                    <th className="py-2.5 px-4">Stock Dispo</th>
                    <th className="py-2.5 px-4 text-right">Coût Ultra SMS (XOF)</th>
                    <th className="py-2.5 px-4 text-right">Prix Client Estimé</th>
                    <th className="py-2.5 px-4 text-center">État</th>
                    <th className="py-2.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                  {catalog.map((item) => {
                    const country = COUNTRIES.find((c) => c.code === item.countryCode);
                    const service = SERVICES.find((s) => s.id === item.serviceId);
                    if (!country || !service) return null;

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                        <td className="py-3 px-4 font-sans font-medium text-slate-800 dark:text-slate-200">
                          {country.flag} {country.name} ({country.prefix})
                        </td>
                        <td className="py-3 px-4 font-sans font-bold text-slate-900 dark:text-white">
                          {service.name}
                        </td>
                        <td className="py-3 px-4 text-slate-500">{item.availableCount} dispos</td>
                        <td className="py-3 px-4 text-right">
                          <input
                            type="number"
                            step="50"
                            value={item.supplierCostXof}
                            onChange={(e) =>
                              updateCatalogItem(item.id, { supplierCostXof: Number(e.target.value) })
                            }
                            className="w-24 px-2 py-1 text-right font-mono text-xs rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                          />
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-emerald-600 dark:text-emerald-400">
                          {(item.supplierCostXof + pricingConfig.targetMarginXof + 100).toLocaleString('fr-FR')} XOF
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              item.enabled
                                ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400'
                                : 'bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                            }`}
                          >
                            {item.enabled ? 'ACTIF' : 'SUSPENDU'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-sans">
                          <button
                            onClick={() => updateCatalogItem(item.id, { enabled: !item.enabled })}
                            className="text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600"
                          >
                            {item.enabled ? 'Désactiver' : 'Activer'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: PRICING RULES EDITOR */}
        {adminTab === 'pricing' && (
          <div className="max-w-2xl mx-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-600 flex items-center justify-center">
                <Sliders className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Configuration de la Règle de Marge & Commissions
                </h3>
                <p className="text-xs text-slate-500">
                  Ajustez les constantes de la formule : P = (C + F + FX + M) / (1 - r)
                </p>
              </div>
            </div>

            <form onSubmit={handleSavePricing} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-900 dark:text-white mb-1">
                  Marge nette cible par numéro vendu (M) :
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="500"
                    step="100"
                    value={targetMarginInput}
                    onChange={(e) => setTargetMarginInput(Number(e.target.value))}
                    className="w-full text-base font-bold font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 text-slate-900 dark:text-slate-100"
                  />
                  <span className="font-mono text-slate-500 font-bold shrink-0">XOF (CFA)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Spécification originale : 2 000 XOF minimum net garanti pour chaque vente.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Commission Mobile Money (%) :
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="10"
                    value={momoRateInput}
                    onChange={(e) => setMomoRateInput(Number(e.target.value))}
                    className="w-full text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">FedaPay / KKiaPay (~1.8%)</p>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Commission Cartes Bancaires (%) :
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="10"
                    value={cardRateInput}
                    onChange={(e) => setCardRateInput(Number(e.target.value))}
                    className="w-full text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Visa / Mastercard (~3.6%)</p>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Pas d'arrondi commercial supérieur :
                </label>
                <select
                  value={roundingStepInput}
                  onChange={(e) => setRoundingStepInput(Number(e.target.value))}
                  className="w-full text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5"
                >
                  <option value="50">50 XOF</option>
                  <option value="100">100 XOF (Conseillé)</option>
                  <option value="500">500 XOF</option>
                </select>
              </div>

              {pricingSavedToast && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 rounded-lg flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Règles tarifaires appliquées instantanément à tout le catalogue.</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 px-4 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-sm"
              >
                Sauvegarder les règles de rentabilité
              </button>
            </form>
          </div>
        )}

        {/* TAB 5: ULTRA SMS PROVIDER */}
        {adminTab === 'provider' && (
          <div className="max-w-2xl mx-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Fournisseur Grossiste Télécoms : Ultra SMS
                  </h3>
                  <p className="text-xs text-slate-500">
                    Configuration des accès API revendeur et webhooks de réception SMS
                  </p>
                </div>
              </div>

              <div className="text-right font-mono">
                <div className="text-[10px] text-slate-400">Solde revendeur Ultra SMS</div>
                <div className="text-sm font-bold text-emerald-600">
                  {providerConfig.balanceXof.toLocaleString('fr-FR')} XOF
                </div>
              </div>
            </div>

            <form onSubmit={handleSaveProvider} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Clé API Revendeur Ultra SMS (Serveur) :
                </label>
                <input
                  type="password"
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  className="w-full font-mono text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  URL Webhook de réception SMS (Numivo Endpoint) :
                </label>
                <input
                  type="text"
                  readOnly
                  value="https://api.numivo.com/api/webhooks/ultrasms/inbound"
                  className="w-full font-mono text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/50 p-2.5 text-slate-500"
                />
              </div>

              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">
                    Mode Environnement Sandbox / Test
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Permet d'émettre des SMS virtuels et tester l'expérience sans débiter le compte réel Ultra SMS.
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsSandboxInput(!isSandboxInput)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                    isSandboxInput
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border border-amber-300'
                      : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-300'
                  }`}
                >
                  {isSandboxInput ? 'SANDBOX ACTIF' : 'PRODUCTION LIVE'}
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
              >
                Mettre à jour la configuration Ultra SMS
              </button>
            </form>
          </div>
        )}

        {/* TAB 6: AUDIT LOGS */}
        {adminTab === 'audit' && (
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Journal d'Audit Système & Sécurité
              </h3>
              <p className="text-xs text-slate-500">
                Traçabilité des opérations critiques, modifications tarifaires et commandes
              </p>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono text-xs">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-3.5 hover:bg-slate-50/50 dark:hover:bg-slate-800/30 flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">
                        {log.action}
                      </span>
                      <span className="text-[10px] text-slate-400">[{log.entityType}]</span>
                      <span className="text-slate-500 text-[11px]">par {log.actor}</span>
                    </div>
                    <p className="font-sans text-xs text-slate-700 dark:text-slate-300">
                      {log.metadata}
                    </p>
                  </div>
                  <div className="text-[10px] text-slate-400 shrink-0">
                    {new Date(log.timestamp).toLocaleString('fr-FR')}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
