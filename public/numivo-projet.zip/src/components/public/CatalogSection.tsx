import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { COUNTRIES, SERVICES } from '../../data/mockData';
import { calculateSellingPrice } from '../../utils/pricing';
import { Search, Filter, MessageCircle, Send, Bot, Mail, Video, Camera, AppWindow, Flame, Car, Tv, Coins, CreditCard, Sparkles, Check } from 'lucide-react';
import { NumberType } from '../../types';

interface CatalogSectionProps {
  onSelectProduct: (countryCode: string, serviceId: string, type: NumberType) => void;
}

export const CatalogSection: React.FC<CatalogSectionProps> = ({ onSelectProduct }) => {
  const { catalog, currency, pricingConfig, exchangeRates } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<NumberType>('TEMPORARY');

  // Service icon resolver helper
  const renderServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'MessageCircle': return <MessageCircle className="w-5 h-5" />;
      case 'Send': return <Send className="w-5 h-5" />;
      case 'Bot': return <Bot className="w-5 h-5" />;
      case 'Mail': return <Mail className="w-5 h-5" />;
      case 'Video': return <Video className="w-5 h-5" />;
      case 'Camera': return <Camera className="w-5 h-5" />;
      case 'Flame': return <Flame className="w-5 h-5" />;
      case 'Car': return <Car className="w-5 h-5" />;
      case 'Tv': return <Tv className="w-5 h-5" />;
      case 'Coins': return <Coins className="w-5 h-5" />;
      case 'CreditCard': return <CreditCard className="w-5 h-5" />;
      default: return <AppWindow className="w-5 h-5" />;
    }
  };

  // Filter items
  const filteredCatalog = useMemo(() => {
    return catalog.filter((item) => {
      if (!item.enabled) return false;
      if (item.type !== selectedType) return false;

      // Country filter
      if (selectedCountry !== 'ALL' && item.countryCode !== selectedCountry) {
        return false;
      }

      // Service data
      const service = SERVICES.find((s) => s.id === item.serviceId);
      const country = COUNTRIES.find((c) => c.code === item.countryCode);

      if (!service || !country) return false;

      // Category filter
      if (selectedCategory !== 'all' && service.category !== selectedCategory) {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = service.name.toLowerCase().includes(query);
        const matchesCountry = country.name.toLowerCase().includes(query);
        const matchesPrefix = country.prefix.includes(query);
        if (!matchesName && !matchesCountry && !matchesPrefix) return false;
      }

      return true;
    });
  }, [catalog, selectedCountry, selectedCategory, selectedType, searchQuery]);

  return (
    <section id="catalog-section" className="py-12 bg-white dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              <span>Fournisseur Ultra SMS</span>
              <span aria-hidden="true">·</span>
              <span>Disponibilité instantanée</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              Catalogue de Numéros Virtuels
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
              Choisissez votre pays et l'application cible. Tarifs calculés en direct selon la devise sélectionnée ({currency}).
            </p>
          </div>

          {/* Type Toggle (Temporary vs Rental) */}
          <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 shrink-0">
            <button
              onClick={() => setSelectedType('TEMPORARY')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${
                selectedType === 'TEMPORARY'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Activation SMS (20 min)
            </button>
            <button
              onClick={() => setSelectedType('RENTAL')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${
                selectedType === 'RENTAL'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Location longue durée
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="py-6 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher WhatsApp, France, +229, Bénin, Google..."
              className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 lg:pb-0 scrollbar-none text-xs">
            {[
              { id: 'all', label: 'Toutes les catégories' },
              { id: 'messaging', label: 'Messageries' },
              { id: 'social', label: 'Réseaux Sociaux' },
              { id: 'ai', label: 'Intelligence Artificielle' },
              { id: 'tech', label: 'Tech & Google' },
              { id: 'fintech', label: 'Banques & Crypto' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 font-medium rounded-lg transition-colors whitespace-nowrap ${
                  selectedCategory === cat.id
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

        </div>

        {/* Country Filter Chips (Interactive filter buttons) */}
        <div className="pb-6 flex items-center gap-2 overflow-x-auto scrollbar-none text-xs">
          <span className="text-slate-400 text-[11px] font-semibold uppercase tracking-wider shrink-0 mr-1">
            Pays :
          </span>
          <button
            onClick={() => setSelectedCountry('ALL')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors shrink-0 ${
              selectedCountry === 'ALL'
                ? 'bg-emerald-600 text-white font-semibold'
                : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            🌍 Tous les pays
          </button>
          {COUNTRIES.map((c) => (
            <button
              key={c.code}
              onClick={() => setSelectedCountry(c.code)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-colors shrink-0 ${
                selectedCountry === c.code
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <span>{c.flag}</span>
              <span>{c.name}</span>
            </button>
          ))}
        </div>

        {/* Catalog Grid */}
        {filteredCatalog.length === 0 ? (
          <div className="py-16 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-8">
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              Aucun numéro disponible pour cette recherche
            </p>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              Essayez de sélectionner un autre pays ou réinitialisez vos filtres pour voir les offres disponibles sur Ultra SMS.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCountry('ALL');
                setSelectedCategory('all');
              }}
              className="mt-4 px-4 py-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              Réinitialiser les filtres
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredCatalog.map((item) => {
              const service = SERVICES.find((s) => s.id === item.serviceId);
              const country = COUNTRIES.find((c) => c.code === item.countryCode);
              if (!service || !country) return null;

              const priceCalc = calculateSellingPrice({
                supplierCostXof: item.supplierCostXof,
                paymentMethod: 'MOBILE_MONEY',
                targetCurrency: currency,
                config: pricingConfig,
                rates: exchangeRates,
              });

              return (
                <div
                  key={item.id}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/80 p-4 hover:border-emerald-500/50 hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Header: Service icon & Country Flag */}
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="w-10 h-10 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                        {renderServiceIcon(service.iconName)}
                      </div>
                      
                      {/* Country Flag & Prefix */}
                      <div className="flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300">
                        <span className="text-base">{country.flag}</span>
                        <span>{country.name}</span>
                        <span className="text-slate-400 font-mono text-[11px]">{country.prefix}</span>
                      </div>
                    </div>

                    {/* Service Name */}
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {service.name}
                    </h3>

                    {/* Unboxed metadata line with typographic separator */}
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
                      <span className="capitalize">{service.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{item.availableCount} dispos</span>
                      <span aria-hidden="true">·</span>
                      <span>20 min</span>
                    </div>
                  </div>

                  {/* Pricing and Action */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
                    <div>
                      <div className="text-[10px] text-slate-400 font-mono uppercase">
                        Prix TTC
                      </div>
                      <div className="text-base font-extrabold font-mono text-emerald-600 dark:text-emerald-400">
                        {priceCalc.sellingPriceFormatted}
                      </div>
                    </div>

                    <button
                      onClick={() => onSelectProduct(item.countryCode, item.serviceId, item.type)}
                      className="px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors whitespace-nowrap shadow-xs"
                    >
                      Acheter
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
