import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Currency, UserRole } from '../../types';
import { Moon, Sun, Shield, User, Globe, ChevronDown, Check, Smartphone, LogOut, Download } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenBuyModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenBuyModal }) => {
  const { role, setRole, currency, setCurrency, theme, toggleTheme, wallet, currentUser, logout } = useApp();
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [currencyMenuOpen, setCurrencyMenuOpen] = useState(false);

  const currencies: { code: Currency; label: string; symbol: string }[] = [
    { code: 'XOF', label: 'Franc CFA (XOF)', symbol: 'CFA' },
    { code: 'EUR', label: 'Euro (EUR)', symbol: '€' },
    { code: 'USD', label: 'Dollar US (USD)', symbol: '$' },
  ];

  const roles: { id: UserRole; label: string; icon: typeof User; badge: string }[] = [
    { id: 'VISITOR', label: 'Visiteur public', icon: Globe, badge: 'Vitrine' },
    { id: 'CLIENT', label: 'Client (Jean Dupont)', icon: User, badge: 'Mon Compte' },
    { id: 'ADMIN', label: 'Administrateur', icon: Shield, badge: 'Console Admin' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('explore')}
            className="flex items-center gap-2.5 text-left focus:outline-none"
          >
            <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold text-lg shadow-sm">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
              Numivo
            </span>
          </button>
        </div>

        {/* Zone 2: 4–5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button
            onClick={() => setActiveTab('explore')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-600 dark:hover:text-emerald-400 ${
              activeTab === 'explore' ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : ''
            }`}
          >
            Catalogue
          </button>
          
          <button
            onClick={() => setActiveTab('pricing-rules')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-600 dark:hover:text-emerald-400 ${
              activeTab === 'pricing-rules' ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : ''
            }`}
          >
            Règle de marge (2 000 XOF)
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-600 dark:hover:text-emerald-400 ${
              activeTab === 'payments' ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : ''
            }`}
          >
            Mobile Money & Cartes
          </button>

          <button
            onClick={() => setActiveTab('faq')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-600 dark:hover:text-emerald-400 ${
              activeTab === 'faq' ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : ''
            }`}
          >
            Conformité & FAQ
          </button>

          {role === 'VISITOR' && (
            <button
              onClick={() => setActiveTab('auth')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-600 dark:hover:text-emerald-400 ${
                activeTab === 'auth' ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : ''
              }`}
            >
              Connexion / Inscription
            </button>
          )}

          {role === 'CLIENT' && (
            <button
              onClick={() => setActiveTab('client-portal')}
              className={`whitespace-nowrap transition-colors text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1.5`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
              Espace Client
            </button>
          )}

          {role === 'ADMIN' && (
            <button
              onClick={() => setActiveTab('admin-portal')}
              className={`whitespace-nowrap transition-colors text-indigo-600 dark:text-indigo-400 font-semibold flex items-center gap-1.5`}
            >
              <Shield className="w-4 h-4" />
              Console Admin
            </button>
          )}
        </nav>

        {/* Zone 3: 1 primary action cluster */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* Currency Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setCurrencyMenuOpen(!currencyMenuOpen);
                setRoleMenuOpen(false);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Devise d'affichage"
            >
              <span>{currency}</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-60" />
            </button>

            {currencyMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-1 z-50">
                <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Devise d'affichage
                </div>
                {currencies.map((curr) => (
                  <button
                    key={curr.code}
                    onClick={() => {
                      setCurrency(curr.code);
                      setCurrencyMenuOpen(false);
                    }}
                    className="w-full flex items-center justify-between px-3 py-2 text-xs text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    <span className="font-medium">{curr.label}</span>
                    {currency === curr.code && <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Download ZIP button */}
          <a
            href="/numivo-projet.zip"
            download="numivo-projet.zip"
            className="p-2 text-slate-500 hover:text-emerald-600 dark:text-slate-400 dark:hover:text-emerald-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Télécharger l'archive ZIP du projet"
            aria-label="Télécharger ZIP"
          >
            <Download className="w-4 h-4" />
          </a>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={theme === 'dark' ? 'Passer au mode clair' : 'Passer au mode sombre'}
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
          </button>

          {/* Role Switcher Pill */}
          <div className="relative">
            <button
              onClick={() => {
                setRoleMenuOpen(!roleMenuOpen);
                setCurrencyMenuOpen(false);
              }}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 hover:border-emerald-500 transition-colors"
            >
              {role === 'ADMIN' && <Shield className="w-3.5 h-3.5 text-indigo-500" />}
              {role === 'CLIENT' && <User className="w-3.5 h-3.5 text-emerald-500" />}
              {role === 'VISITOR' && <Globe className="w-3.5 h-3.5 text-slate-400" />}
              <span className="hidden sm:inline font-semibold">
                {role === 'ADMIN' ? 'Admin' : role === 'CLIENT' ? 'Client' : 'Visiteur'}
              </span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>

            {roleMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-1 z-50">
                <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Changer de rôle (Démonstrateur)
                </div>
                {roles.map((r) => {
                  const Icon = r.icon;
                  return (
                    <button
                      key={r.id}
                      onClick={() => {
                        setRole(r.id);
                        setRoleMenuOpen(false);
                        if (r.id === 'ADMIN') setActiveTab('admin-portal');
                        else if (r.id === 'CLIENT') setActiveTab('client-portal');
                        else setActiveTab('explore');
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 text-xs text-left hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
                        role === r.id ? 'bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 font-semibold' : 'text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className="w-4 h-4 opacity-75" />
                        <span>{r.label}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                        {r.badge}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Primary Actions based on Auth & Role */}
          {role === 'ADMIN' ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('admin-portal')}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm"
              >
                Console Admin
              </button>
              <button
                onClick={() => {
                  logout();
                  setActiveTab('explore');
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Déconnexion"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : role === 'CLIENT' ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('client-portal')}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm"
              >
                Mon Espace ({wallet.balances[currency].toLocaleString('fr-FR')} {currency})
              </button>
              <button
                onClick={() => {
                  logout();
                  setActiveTab('explore');
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Déconnexion"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('auth')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-emerald-600 dark:hover:text-emerald-400 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                Connexion
              </button>
              <button
                onClick={() => {
                  if (onOpenBuyModal) onOpenBuyModal();
                  else setActiveTab('explore');
                }}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm"
              >
                Acheter un numéro
              </button>
            </div>
          )}

        </div>

      </div>
    </header>
  );
};
