export type Currency = 'XOF' | 'EUR' | 'USD';

export type UserRole = 'VISITOR' | 'CLIENT' | 'ADMIN';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  country: string;
  phone?: string;
  preferredCurrency: Currency;
  createdAt: string;
}

export type NumberType = 'TEMPORARY' | 'RENTAL';

export type PaymentMethod = 'MOBILE_MONEY' | 'CARD' | 'WALLET';

export type PaymentProvider = 'FEDAPAY' | 'KKIAPAY' | 'CARD_GATEWAY' | 'WALLET';

export type MobileMoneyOperator = 'MTN' | 'MOOV' | 'CELTIIS';

export type OrderStatus =
  | 'PENDING_PAYMENT'
  | 'PAID'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'REFUNDED';

export interface Country {
  code: string;
  name: string;
  flag: string;
  prefix: string;
  popular?: boolean;
}

export interface ServiceItem {
  id: string;
  name: string;
  iconName: string;
  category: 'social' | 'ai' | 'messaging' | 'tech' | 'fintech';
  popular?: boolean;
}

export interface CatalogItem {
  id: string;
  countryCode: string;
  serviceId: string;
  type: NumberType;
  supplierCostXof: number; // Base cost from Ultra SMS in XOF
  availableCount: number;
  enabled: boolean;
}

export interface PricingConfig {
  targetMarginXof: number; // Default 2000 XOF
  paymentRateMobileMoney: number; // 0.018 (1.8%)
  paymentRateCard: number; // 0.036 (3.6%)
  paymentRateWallet: number; // 0.00 (0%)
  fixedPaymentFeeXof: number; // 0 XOF
  fxFeeRate: number; // 0.00
  roundingStepXof: number; // 100 XOF
}

export interface ExchangeRates {
  EUR_XOF: number; // 655.957
  USD_XOF: number; // 615.0
  EUR_USD: number; // 1.0665
}

export interface PriceBreakdown {
  supplierCostXof: number;
  targetMarginXof: number;
  paymentFeeXof: number;
  fxFeeXof: number;
  rawPriceXof: number;
  sellingPriceXof: number;
  estimatedNetMarginXof: number;
  // Converted to target currency
  currency: Currency;
  sellingPriceFormatted: string;
  sellingPriceInCurrency: number;
  rateApplied: number;
}

export interface SmsMessage {
  id: string;
  orderId: string;
  sender: string;
  messageText: string;
  extractedOtpCode?: string;
  receivedAt: string;
}

export interface Order {
  id: string;
  reference: string;
  userId: string;
  userEmail: string;
  countryCode: string;
  countryName: string;
  prefix: string;
  serviceId: string;
  serviceName: string;
  phoneNumber?: string;
  type: NumberType;
  currency: Currency;
  supplierCostXof: number;
  exchangeRateUsed: number;
  sellingPriceXof: number;
  sellingPriceCurrency: number;
  paymentFeeXof: number;
  actualMarginXof: number;
  paymentMethod: PaymentMethod;
  paymentProvider: PaymentProvider;
  mobileMoneyOperator?: MobileMoneyOperator;
  mobileMoneyPhone?: string;
  status: OrderStatus;
  createdAt: string;
  expiresAt: string;
  completedAt?: string;
  smsMessages: SmsMessage[];
}

export type WalletTransactionType = 'DEPOSIT' | 'PURCHASE' | 'REFUND' | 'ADJUSTMENT';

export interface WalletTransaction {
  id: string;
  reference: string;
  date: string;
  type: WalletTransactionType;
  currency: Currency;
  amount: number;
  balanceAfter: number;
  status: 'CONFIRMED' | 'PENDING' | 'CANCELLED';
  description: string;
  paymentMethod?: string;
  idempotencyKey?: string;
}

export interface UserWallet {
  userId: string;
  balances: Record<Currency, number>;
  transactions: WalletTransaction[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  entityType: string;
  entityId: string;
  metadata?: string;
}

export interface UltraSmsProviderConfig {
  apiKey: string;
  apiEndpoint: string;
  isSandbox: boolean;
  connected: boolean;
  balanceXof: number;
  lastPing: string;
}
