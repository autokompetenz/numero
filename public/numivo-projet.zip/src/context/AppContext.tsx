import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  AuditLog,
  CatalogItem,
  Currency,
  ExchangeRates,
  MobileMoneyOperator,
  NumberType,
  Order,
  PaymentMethod,
  PaymentProvider,
  PricingConfig,
  UltraSmsProviderConfig,
  UserRole,
  UserProfile,
  UserWallet,
  WalletTransaction,
} from '../types';
import {
  COUNTRIES,
  INITIAL_AUDIT_LOGS,
  INITIAL_CATALOG,
  INITIAL_ORDERS,
  INITIAL_ULTRA_SMS_CONFIG,
  INITIAL_WALLET,
  SERVICES,
} from '../data/mockData';
import {
  calculateSellingPrice,
  DEFAULT_EXCHANGE_RATES,
  DEFAULT_PRICING_CONFIG,
} from '../utils/pricing';

interface AppContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  catalog: CatalogItem[];
  orders: Order[];
  wallet: UserWallet;
  pricingConfig: PricingConfig;
  exchangeRates: ExchangeRates;
  providerConfig: UltraSmsProviderConfig;
  auditLogs: AuditLog[];

  // Actions
  createOrder: (params: {
    countryCode: string;
    serviceId: string;
    type: NumberType;
    paymentMethod: PaymentMethod;
    mobileMoneyOperator?: MobileMoneyOperator;
    mobileMoneyPhone?: string;
  }) => Promise<{ order: Order; success: boolean; error?: string }>;
  
  simulateSmsReception: (orderId: string, customSender?: string, customCode?: string) => void;
  cancelAndRefundOrder: (orderId: string, reason?: string) => Promise<boolean>;
  currentUser: UserProfile | null;
  login: (email: string, password?: string) => Promise<{ success: boolean; user?: UserProfile; error?: string }>;
  register: (data: {
    name: string;
    email: string;
    password?: string;
    country: string;
    phone?: string;
    preferredCurrency: Currency;
  }) => Promise<{ success: boolean; user?: UserProfile; error?: string }>;
  logout: () => void;
  depositToWallet: (currency: Currency, amount: number, paymentMethod: string) => Promise<boolean>;
  updatePricingConfig: (newConfig: Partial<PricingConfig>) => void;
  updateCatalogItem: (id: string, updates: Partial<CatalogItem>) => void;
  updateProviderConfig: (updates: Partial<UltraSmsProviderConfig>) => void;
  syncProvider: () => Promise<void>;
  resetToInitialDemo: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('numivo_theme') as 'dark' | 'light') || 'dark';
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('numivo_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Default initial users
  const DEFAULT_CLIENT_USER: UserProfile = {
    id: 'usr-client-01',
    name: 'Jean Dupont',
    email: 'client@numivo.com',
    role: 'CLIENT',
    country: 'Bénin',
    phone: '+229 97 00 11 22',
    preferredCurrency: 'XOF',
    createdAt: '2026-01-15T09:00:00.000Z',
  };

  const DEFAULT_ADMIN_USER: UserProfile = {
    id: 'usr-admin-01',
    name: 'Administrateur Numivo',
    email: 'admin@numivo.com',
    role: 'ADMIN',
    country: 'Bénin',
    preferredCurrency: 'XOF',
    createdAt: '2025-11-01T08:00:00.000Z',
  };

  // User auth state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('numivo_user');
    if (saved) return JSON.parse(saved);
    const savedRole = localStorage.getItem('numivo_role');
    if (savedRole === 'ADMIN') return DEFAULT_ADMIN_USER;
    if (savedRole === 'CLIENT') return DEFAULT_CLIENT_USER;
    return null;
  });

  // Role state
  const [role, setRoleState] = useState<UserRole>(() => {
    return (localStorage.getItem('numivo_role') as UserRole) || 'VISITOR';
  });

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    localStorage.setItem('numivo_role', newRole);
    if (newRole === 'ADMIN') {
      setCurrentUser(DEFAULT_ADMIN_USER);
      localStorage.setItem('numivo_user', JSON.stringify(DEFAULT_ADMIN_USER));
    } else if (newRole === 'CLIENT') {
      setCurrentUser(DEFAULT_CLIENT_USER);
      localStorage.setItem('numivo_user', JSON.stringify(DEFAULT_CLIENT_USER));
    } else {
      setCurrentUser(null);
      localStorage.removeItem('numivo_user');
    }
  };

  // Auth functions
  const login = async (email: string, _password?: string) => {
    const trimmed = email.trim().toLowerCase();
    if (trimmed.includes('admin')) {
      setCurrentUser(DEFAULT_ADMIN_USER);
      setRoleState('ADMIN');
      localStorage.setItem('numivo_role', 'ADMIN');
      localStorage.setItem('numivo_user', JSON.stringify(DEFAULT_ADMIN_USER));
      addAuditLog('USER_LOGIN', 'AUTH', DEFAULT_ADMIN_USER.id, `Connexion réussie Administrateur (${email})`);
      return { success: true, user: DEFAULT_ADMIN_USER };
    }

    const clientUser: UserProfile = {
      id: `usr-${Date.now()}`,
      name: trimmed === 'client@numivo.com' ? 'Jean Dupont' : trimmed.split('@')[0],
      email: trimmed,
      role: 'CLIENT',
      country: 'Bénin',
      preferredCurrency: currency,
      createdAt: new Date().toISOString(),
    };

    setCurrentUser(clientUser);
    setRoleState('CLIENT');
    localStorage.setItem('numivo_role', 'CLIENT');
    localStorage.setItem('numivo_user', JSON.stringify(clientUser));
    addAuditLog('USER_LOGIN', 'AUTH', clientUser.id, `Connexion réussie Client (${email})`);
    return { success: true, user: clientUser };
  };

  const register = async (data: {
    name: string;
    email: string;
    password?: string;
    country: string;
    phone?: string;
    preferredCurrency: Currency;
  }) => {
    const newUser: UserProfile = {
      id: `usr-${Date.now()}`,
      name: data.name.trim(),
      email: data.email.trim().toLowerCase(),
      role: 'CLIENT',
      country: data.country,
      phone: data.phone,
      preferredCurrency: data.preferredCurrency,
      createdAt: new Date().toISOString(),
    };

    setCurrentUser(newUser);
    setRoleState('CLIENT');
    setCurrency(data.preferredCurrency);
    localStorage.setItem('numivo_role', 'CLIENT');
    localStorage.setItem('numivo_user', JSON.stringify(newUser));
    addAuditLog('USER_REGISTERED', 'AUTH', newUser.id, `Nouvelle inscription client (${newUser.email}) depuis ${data.country}`);
    return { success: true, user: newUser };
  };

  const logout = () => {
    setCurrentUser(null);
    setRoleState('VISITOR');
    localStorage.removeItem('numivo_user');
    localStorage.setItem('numivo_role', 'VISITOR');
    addAuditLog('USER_LOGOUT', 'AUTH', 'current', 'Déconnexion utilisateur');
  };

  // Currency state
  const [currency, setCurrencyState] = useState<Currency>(() => {
    return (localStorage.getItem('numivo_currency') as Currency) || 'XOF';
  });

  const setCurrency = (newCurrency: Currency) => {
    setCurrencyState(newCurrency);
    localStorage.setItem('numivo_currency', newCurrency);
  };

  // Core business states
  const [catalog, setCatalog] = useState<CatalogItem[]>(() => {
    const saved = localStorage.getItem('numivo_catalog');
    return saved ? JSON.parse(saved) : INITIAL_CATALOG;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('numivo_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [wallet, setWallet] = useState<UserWallet>(() => {
    const saved = localStorage.getItem('numivo_wallet');
    return saved ? JSON.parse(saved) : INITIAL_WALLET;
  });

  const [pricingConfig, setPricingConfig] = useState<PricingConfig>(() => {
    const saved = localStorage.getItem('numivo_pricing_config');
    return saved ? JSON.parse(saved) : DEFAULT_PRICING_CONFIG;
  });

  const [exchangeRates] = useState<ExchangeRates>(DEFAULT_EXCHANGE_RATES);

  const [providerConfig, setProviderConfig] = useState<UltraSmsProviderConfig>(() => {
    const saved = localStorage.getItem('numivo_provider_config');
    return saved ? JSON.parse(saved) : INITIAL_ULTRA_SMS_CONFIG;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem('numivo_audit_logs');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('numivo_catalog', JSON.stringify(catalog));
  }, [catalog]);

  useEffect(() => {
    localStorage.setItem('numivo_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('numivo_wallet', JSON.stringify(wallet));
  }, [wallet]);

  useEffect(() => {
    localStorage.setItem('numivo_pricing_config', JSON.stringify(pricingConfig));
  }, [pricingConfig]);

  useEffect(() => {
    localStorage.setItem('numivo_provider_config', JSON.stringify(providerConfig));
  }, [providerConfig]);

  useEffect(() => {
    localStorage.setItem('numivo_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  // Log helper
  const addAuditLog = (action: string, entityType: string, entityId: string, metadata: string) => {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      actor: role === 'ADMIN' ? 'admin@numivo.com' : 'client@numivo.com',
      action,
      entityType,
      entityId,
      metadata,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Helper to generate a realistic phone number based on prefix
  const generatePhoneNumber = (prefix: string): string => {
    const randDigits = Math.floor(10000000 + Math.random() * 90000000);
    if (prefix === '+229') {
      const part1 = Math.floor(90 + Math.random() * 9);
      const part2 = Math.floor(10 + Math.random() * 89);
      const part3 = Math.floor(10 + Math.random() * 89);
      const part4 = Math.floor(10 + Math.random() * 89);
      return `+229 ${part1} ${part2} ${part3} ${part4}`;
    }
    if (prefix === '+33') {
      const part1 = Math.floor(10 + Math.random() * 89);
      const part2 = Math.floor(10 + Math.random() * 89);
      const part3 = Math.floor(10 + Math.random() * 89);
      const part4 = Math.floor(10 + Math.random() * 89);
      return `+33 6 ${part1} ${part2} ${part3} ${part4}`;
    }
    if (prefix === '+1') {
      const area = Math.floor(200 + Math.random() * 799);
      const mid = Math.floor(200 + Math.random() * 799);
      const last = Math.floor(1000 + Math.random() * 8999);
      return `+1 ${area} ${mid} ${last}`;
    }
    return `${prefix} ${randDigits}`;
  };

  // ORDER CREATION FLOW (Section 5: Parcours d'achat d'un numéro)
  const createOrder = async ({
    countryCode,
    serviceId,
    type,
    paymentMethod,
    mobileMoneyOperator,
    mobileMoneyPhone,
  }: {
    countryCode: string;
    serviceId: string;
    type: NumberType;
    paymentMethod: PaymentMethod;
    mobileMoneyOperator?: MobileMoneyOperator;
    mobileMoneyPhone?: string;
  }): Promise<{ order: Order; success: boolean; error?: string }> => {
    // 1. Find catalog item
    const catalogItem = catalog.find(
      (c) => c.countryCode === countryCode && c.serviceId === serviceId && c.type === type
    );
    const country = COUNTRIES.find((c) => c.code === countryCode);
    const service = SERVICES.find((s) => s.id === serviceId);

    if (!catalogItem || !country || !service) {
      return { order: {} as Order, success: false, error: 'Produit non disponible au catalogue.' };
    }

    // 2. Calculate final selling price according to 2 000 XOF margin rule
    const priceCalculation = calculateSellingPrice({
      supplierCostXof: catalogItem.supplierCostXof,
      paymentMethod,
      targetCurrency: currency,
      config: pricingConfig,
      rates: exchangeRates,
    });

    // 3. Handle Wallet payment deduction if method is WALLET
    if (paymentMethod === 'WALLET') {
      const currentBalance = wallet.balances[currency];
      if (currentBalance < priceCalculation.sellingPriceInCurrency) {
        return {
          order: {} as Order,
          success: false,
          error: `Solde ${currency} insuffisant (${priceCalculation.sellingPriceFormatted} requis, solde actuel : ${currentBalance} ${currency}). Rechargez votre portefeuille.`,
        };
      }

      // Debit wallet atomically
      const newBalance = currentBalance - priceCalculation.sellingPriceInCurrency;
      const newTransaction: WalletTransaction = {
        id: `tx-${Date.now()}`,
        reference: `PUR-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
        date: new Date().toISOString(),
        type: 'PURCHASE',
        currency,
        amount: -priceCalculation.sellingPriceInCurrency,
        balanceAfter: Math.round(newBalance * 100) / 100,
        status: 'CONFIRMED',
        description: `Achat numéro virtuel ${service.name} (${country.name})`,
        paymentMethod: `Portefeuille ${currency}`,
        idempotencyKey: `idemp-ord-${Date.now()}`,
      };

      setWallet((prev) => ({
        ...prev,
        balances: {
          ...prev.balances,
          [currency]: Math.round(newBalance * 100) / 100,
        },
        transactions: [newTransaction, ...prev.transactions],
      }));
    }

    // 4. Determine payment provider
    let paymentProvider: PaymentProvider = 'WALLET';
    if (paymentMethod === 'MOBILE_MONEY') {
      paymentProvider = mobileMoneyOperator === 'MTN' || mobileMoneyOperator === 'MOOV' ? 'FEDAPAY' : 'KKIAPAY';
    } else if (paymentMethod === 'CARD') {
      paymentProvider = 'CARD_GATEWAY';
    }

    // 5. Build order with assigned virtual phone number from Ultra SMS provider
    const orderId = `ord-${Date.now()}`;
    const orderRef = `NUM-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const assignedPhone = generatePhoneNumber(country.prefix);

    const newOrder: Order = {
      id: orderId,
      reference: orderRef,
      userId: wallet.userId,
      userEmail: 'client@numivo.com',
      countryCode,
      countryName: country.name,
      prefix: country.prefix,
      serviceId,
      serviceName: service.name,
      phoneNumber: assignedPhone,
      type,
      currency,
      supplierCostXof: catalogItem.supplierCostXof,
      exchangeRateUsed: priceCalculation.rateApplied,
      sellingPriceXof: priceCalculation.sellingPriceXof,
      sellingPriceCurrency: priceCalculation.sellingPriceInCurrency,
      paymentFeeXof: priceCalculation.paymentFeeXof,
      actualMarginXof: priceCalculation.estimatedNetMarginXof,
      paymentMethod,
      paymentProvider,
      mobileMoneyOperator,
      mobileMoneyPhone,
      status: 'PROCESSING',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 20 * 60 * 1000).toISOString(), // 20 minutes duration
      smsMessages: [],
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Audit log
    addAuditLog(
      'ORDER_CREATED',
      'ORDER',
      newOrder.id,
      `Nouvelle commande ${newOrder.reference} (${service.name} - ${country.name}) payée par ${paymentMethod}. Marge nette : ${priceCalculation.estimatedNetMarginXof} XOF.`
    );

    // Schedule automatic simulated SMS reception after 10 seconds if still processing!
    setTimeout(() => {
      simulateSmsReception(
        orderId,
        service.name,
        Math.floor(100000 + Math.random() * 900000).toString()
      );
    }, 9000);

    return { order: newOrder, success: true };
  };

  // SIMULATE SMS RECEPTION (Live reception from Ultra SMS API)
  const simulateSmsReception = (orderId: string, customSender?: string, customCode?: string) => {
    setOrders((prevOrders) =>
      prevOrders.map((ord) => {
        if (ord.id !== orderId) return ord;
        if (ord.status === 'CANCELLED' || ord.status === 'REFUNDED') return ord;

        const otpCode = customCode || Math.floor(100000 + Math.random() * 900000).toString();
        const sender = customSender || ord.serviceName;
        const msgText = `Votre code de sécurité pour ${sender} est : ${otpCode}. Valable pendant 10 minutes. Numivo Security.`;

        const newSms = {
          id: `sms-${Date.now()}`,
          orderId: ord.id,
          sender,
          messageText: msgText,
          extractedOtpCode: otpCode,
          receivedAt: new Date().toISOString(),
        };

        return {
          ...ord,
          status: 'COMPLETED',
          completedAt: new Date().toISOString(),
          smsMessages: [newSms, ...ord.smsMessages],
        };
      })
    );

    addAuditLog(
      'SMS_RECEIVED',
      'ORDER',
      orderId,
      `SMS reçu du fournisseur Ultra SMS pour la commande ${orderId}. Code OTP extrait avec succès.`
    );
  };

  // CANCEL AND REFUND (Guarantee if no SMS arrived)
  const cancelAndRefundOrder = async (orderId: string, reason = 'Aucun SMS reçu dans le délai imparti'): Promise<boolean> => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return false;

    // Refund back to user's wallet in the order's original currency
    const refundAmount = targetOrder.sellingPriceCurrency;
    const currentBalance = wallet.balances[targetOrder.currency];
    const newBalance = currentBalance + refundAmount;

    const refundTx: WalletTransaction = {
      id: `tx-ref-${Date.now()}`,
      reference: `REF-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString(),
      type: 'REFUND',
      currency: targetOrder.currency,
      amount: refundAmount,
      balanceAfter: Math.round(newBalance * 100) / 100,
      status: 'CONFIRMED',
      description: `Remboursement commande ${targetOrder.reference} (${reason})`,
      paymentMethod: 'Recrédit Portefeuille Immédiat',
      idempotencyKey: `idemp-ref-${orderId}`,
    };

    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'REFUNDED',
            }
          : o
      )
    );

    setWallet((prev) => ({
      ...prev,
      balances: {
        ...prev.balances,
        [targetOrder.currency]: Math.round(newBalance * 100) / 100,
      },
      transactions: [refundTx, ...prev.transactions],
    }));

    addAuditLog(
      'ORDER_REFUNDED',
      'ORDER',
      orderId,
      `Remboursement de ${refundAmount} ${targetOrder.currency} effectué vers le portefeuille client. Motif: ${reason}`
    );

    return true;
  };

  // DEPOSIT TO WALLET
  const depositToWallet = async (
    targetCurrency: Currency,
    amount: number,
    paymentMethod: string
  ): Promise<boolean> => {
    if (amount <= 0) return false;

    const currentBalance = wallet.balances[targetCurrency];
    const newBalance = currentBalance + amount;

    const newTx: WalletTransaction = {
      id: `tx-dep-${Date.now()}`,
      reference: `DEP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString(),
      type: 'DEPOSIT',
      currency: targetCurrency,
      amount,
      balanceAfter: Math.round(newBalance * 100) / 100,
      status: 'CONFIRMED',
      description: `Rechargement portefeuille via ${paymentMethod}`,
      paymentMethod,
      idempotencyKey: `idemp-dep-${Date.now()}`,
    };

    setWallet((prev) => ({
      ...prev,
      balances: {
        ...prev.balances,
        [targetCurrency]: Math.round(newBalance * 100) / 100,
      },
      transactions: [newTx, ...prev.transactions],
    }));

    addAuditLog(
      'WALLET_DEPOSIT',
      'WALLET',
      wallet.userId,
      `Dépôt confirmé de ${amount} ${targetCurrency} via ${paymentMethod}. Nouveau solde : ${newBalance} ${targetCurrency}.`
    );

    return true;
  };

  // ADMIN ACTIONS
  const updatePricingConfig = (newConfig: Partial<PricingConfig>) => {
    setPricingConfig((prev) => ({ ...prev, ...newConfig }));
    addAuditLog(
      'PRICING_CONFIG_UPDATED',
      'CONFIG',
      'pricing_rules',
      `Mise à jour des paramètres tarifaires. Marge cible : ${newConfig.targetMarginXof ?? pricingConfig.targetMarginXof} XOF`
    );
  };

  const updateCatalogItem = (id: string, updates: Partial<CatalogItem>) => {
    setCatalog((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
    addAuditLog('CATALOG_ITEM_UPDATED', 'CATALOG', id, `Modification de l'élément catalogue #${id}`);
  };

  const updateProviderConfig = (updates: Partial<UltraSmsProviderConfig>) => {
    setProviderConfig((prev) => ({ ...prev, ...updates }));
    addAuditLog(
      'PROVIDER_CONFIG_UPDATED',
      'PROVIDER',
      'ultra_sms',
      `Mise à jour configuration Ultra SMS. Mode sandbox : ${updates.isSandbox ?? providerConfig.isSandbox}`
    );
  };

  const syncProvider = async () => {
    setProviderConfig((prev) => ({
      ...prev,
      connected: true,
      lastPing: new Date().toISOString(),
    }));
    addAuditLog('PROVIDER_SYNCED', 'PROVIDER', 'ultra_sms', 'Test de ping API Ultra SMS réussi.');
  };

  const resetToInitialDemo = () => {
    setCatalog(INITIAL_CATALOG);
    setOrders(INITIAL_ORDERS);
    setWallet(INITIAL_WALLET);
    setPricingConfig(DEFAULT_PRICING_CONFIG);
    setProviderConfig(INITIAL_ULTRA_SMS_CONFIG);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    localStorage.clear();
    setRole('VISITOR');
    setCurrency('XOF');
  };

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        currency,
        setCurrency,
        theme,
        toggleTheme,
        catalog,
        orders,
        wallet,
        pricingConfig,
        exchangeRates,
        providerConfig,
        auditLogs,
        createOrder,
        simulateSmsReception,
        cancelAndRefundOrder,
        currentUser,
        login,
        register,
        logout,
        depositToWallet,
        updatePricingConfig,
        updateCatalogItem,
        updateProviderConfig,
        syncProvider,
        resetToInitialDemo,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
